#import <RCTAppDelegate.h>
#import <UIKit/UIKit.h>

@interface AppDelegate : RCTAppDelegate
@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, strong) UIViewController *reactNativeViewController;

@end
