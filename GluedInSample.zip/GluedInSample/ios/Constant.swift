//
//  Constant.swift
//  GluedInSample
//
//  Created by sahil on 05/09/24.
//

import Foundation


enum EventTypes : String{
  case hashTagClick = "hashtag"
  case challengeClick = "challenge"
}
