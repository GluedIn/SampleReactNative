const Constant = {
    StorageKeys:{
        isUserLoggedIn : 'isUserLoggedIn',
    }
}

export default Constant